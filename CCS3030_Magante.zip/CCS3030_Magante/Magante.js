let count = 0;

function countClicks() {
    count++;
    document.getElementById("countClicks").textContent = "Clicked: " + count;
}
