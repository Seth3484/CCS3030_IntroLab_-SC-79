
window.onload = function() {
 let count = 0;

 function countClicks() {
    count++;
    document.getElementById("countClicks").textContent = "Clicked: " + count;
 }

 startBtn.addEventListener("click", () => {
    if (gameInterval) return; // prevent multiple intervals

    // Reset game state
    snake = [{ x: 10, y: 10 }];
    
    velocity = { x: 1, y: 0 };  // <-- Add this line here
    
    food = { x: 15, y: 15 };
    gameOver = false;
    score = 0;

    gameInterval = setInterval(gameLoop, 100);
    startBtn.disabled = true;
    startBtn.textContent = "Game Running...";
 });


 const canvas = document.getElementById("snakeGame");
 const ctx = canvas.getContext("2d");
 const startBtn = document.getElementById("startBtn");

 const gridSize = 20;
 const tileCount = canvas.width / gridSize;

 let snake = [{ x: 10, y: 10 }];
 let velocity = { x: 0, y: 0 };
 let food = { x: 15, y: 15 };
 let gameOver = false;
 let score = 0;
 let gameInterval = null;

 document.addEventListener("keydown", keyDown);

 startBtn.addEventListener("click", () => {
    if (gameInterval) return; // prevent multiple intervals

    // Reset game state
    snake = [{ x: 10, y: 10 }];
    velocity = { x: 0, y: 0 };
    food = { x: 15, y: 15 };
    gameOver = false;
    score = 0;

    gameInterval = setInterval(gameLoop, 100);
    startBtn.disabled = true;
    startBtn.textContent = "Game Running...";
 });

 function keyDown(e) {
    
    switch (e.key) {
        case "ArrowLeft":
            if (velocity.x === 1) break;
            velocity = { x: -1, y: 0 };
            break;
        case "ArrowRight":
            if (velocity.x === -1) break;
            velocity = { x: 1, y: 0 };
            break;
        case "ArrowUp":
            if (velocity.y === 1) break;
            velocity = { x: 0, y: -1 };
            break;
        case "ArrowDown":
            if (velocity.y === -1) break;
            velocity = { x: 0, y: 1 };
            break;
    }
 }

 function gameLoop() {
    if (gameOver) {
        ctx.fillStyle = "black";
        ctx.font = "30px Arial";
        ctx.textAlign = "center";
        ctx.fillText("Game Over! Score: " + score, canvas.width / 2, canvas.height / 2);
        ctx.font = "20px Arial";
        ctx.fillText("Refresh to play again", canvas.width / 2, canvas.height / 2 + 30);
        clearInterval(gameInterval);
        gameInterval = null;
        startBtn.disabled = false;
        startBtn.textContent = "Start Game";
        return;
    }

    // Same game logic as before
    const head = { x: snake[0].x + velocity.x, y: snake[0].y + velocity.y };

    if (
        head.x < 0 || head.x >= tileCount ||
        head.y < 0 || head.y >= tileCount
    ) {
        gameOver = true;
    }

    for (let segment of snake) {
        if (segment.x === head.x && segment.y === head.y) {
            gameOver = true;
            break;
        }
    }

    if (gameOver) {
        gameLoop();
        return;
    }

    snake.unshift(head);

    if (head.x === food.x && head.y === food.y) {
        score++;
        placeFood();
    } else {
        snake.pop();
    }

    ctx.fillStyle = "#f7f9fc";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#3498db";
    for (let segment of snake) {
        ctx.fillRect(segment.x * gridSize, segment.y * gridSize, gridSize - 2, gridSize - 2);
    }

    ctx.fillStyle = "#e74c3c";
    ctx.fillRect(food.x * gridSize, food.y * gridSize, gridSize - 2, gridSize - 2);

    ctx.fillStyle = "#333";
    ctx.font = "20px Arial";
    ctx.fillText("Score: " + score, 10, 20);
 }

 function placeFood() {
    food.x = Math.floor(Math.random() * tileCount);
    food.y = Math.floor(Math.random() * tileCount);

    for (let segment of snake) {
        if (segment.x === food.x && segment.y === food.y) {
            placeFood();
            break;
        }
    }
 }
}

